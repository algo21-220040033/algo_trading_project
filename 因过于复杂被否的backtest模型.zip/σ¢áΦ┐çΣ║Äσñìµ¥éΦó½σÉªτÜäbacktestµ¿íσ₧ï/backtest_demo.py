from howtrader.app.cta_strategy.backtesting import BacktestingEngine, OptimizationSetting
from howtrader.trader.object import Interval
from datetime import datetime
from howtrader.app.cta_strategy.strategies.atr_rsi_strategy import AtrRsiStrategy

engine = BacktestingEngine()
engine.set_parameters(
    vt_symbol="BTCUSDT.BINANCE",
    interval=Interval.MINUTE,
    start=datetime(2019, 10, 1),
    end=datetime(2020, 5, 1),
    rate=6/ 10000,
    slippage=0,
    size=1,
    pricetick=0.01,
    capital=1_000_000,
)

engine.add_strategy(AtrRsiStrategy, {})#选择策略


engine.load_data()#载入历史数据
engine.run_backtesting()
df = engine.calculate_result()#逐日盯市盈亏
engine.calculate_statistics()#计算数据技术指标
engine.show_chart()#数据可视化

setting = OptimizationSetting()
setting.set_target("sharpe_ratio")
setting.add_parameter("atr_length", 3, 39, 1)#设置参数区间和步长
setting.add_parameter("atr_ma_length", 10, 30, 1)#设置参数区间和步长
""""
其余参数
rsi_length",
"rsi_entry",
"trailing_percent",
"fixed_size"
"""
engine.run_ga_optimization(setting)#利用基因遗传算法求策略参数最优解
